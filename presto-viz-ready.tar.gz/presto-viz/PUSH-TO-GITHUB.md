# Pushing presto-viz to GitHub

The local repository is ready! Follow these steps to push it to GitHub and use it with LMR2.

## ✅ What's Been Done

- ✅ Created local git repository at `/home/user/presto-viz`
- ✅ Copied all visualization files (excluding viz.js)
- ✅ Created README.md with full documentation
- ✅ Created MIT LICENSE
- ✅ Created .gitignore
- ✅ Committed all files to git
- ✅ Total: 12 files, 17,140 lines of code

## 📦 Repository Contents

```
presto-viz/
├── .github/workflows/
│   └── presto-viz-reusable.yml    # Reusable workflow
├── web_assets/
│   ├── assets/
│   │   ├── credits.txt
│   │   ├── logo.png
│   │   └── style.default.css
│   └── visualizer_template.html
├── 1_format_data_daholocene_graphem.py
├── 2_make_maps_and_ts.py
├── 3_make_html_file.py
├── functions_presto.py
├── presto_env.yml
├── run_script.sh
├── .gitignore
├── LICENSE (MIT)
└── README.md
```

**✅ Excluded**: viz.js (server-specific, not needed)

## 🚀 Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Fill in:
   - **Repository name**: `presto-viz`
   - **Description**: "Automated paleoclimate reconstruction visualization pipeline"
   - **Visibility**: **Public** ⚠️ (required for reusable workflow)
3. **DO NOT** initialize with README, .gitignore, or license (we already have them)
4. Click **"Create repository"**

## 🔗 Step 2: Connect and Push

GitHub will show you commands. Use these instead:

```bash
cd /home/user/presto-viz

# Add the remote (replace DaveEdge1 with your username if different)
git remote add origin https://github.com/DaveEdge1/presto-viz.git

# Push to GitHub
git push -u origin main
```

You'll be prompted for authentication. Use:
- Username: Your GitHub username
- Password: Your GitHub Personal Access Token (PAT)

**Don't have a PAT?** Create one:
1. Go to https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Select scopes: `repo` (full control)
4. Copy the token and use as password

## ✅ Step 3: Verify on GitHub

After pushing, visit:
https://github.com/DaveEdge1/presto-viz

Verify:
- [ ] README displays correctly
- [ ] All files are present
- [ ] Workflow file exists at `.github/workflows/presto-viz-reusable.yml`
- [ ] viz.js is NOT present ✅

## 🔬 Step 4: Test with LMR2

Now you can use it! In your LMR2 repository, update or create your workflow:

### Option A: Add to Existing Workflow

```yaml
# In LMR2/.github/workflows/your-workflow.yml

jobs:
  cfr-analysis:
    name: Run CFR Analysis
    runs-on: ubuntu-latest
    steps:
      # ... your existing analysis steps ...

      - name: Upload CFR outputs
        uses: actions/upload-artifact@v4
        with:
          name: cfr-netcdf-output
          path: |
            output/**/*.nc
            output/**/configs.yml

  # Add this new job:
  presto-visualization:
    name: Generate Presto Visualization
    needs: cfr-analysis
    uses: DaveEdge1/presto-viz/.github/workflows/presto-viz-reusable.yml@main
    with:
      reconstruction_id: CFR_${{ github.run_number }}
      artifact_name: cfr-netcdf-output
```

### Option B: Create New Test Workflow

Create `.github/workflows/test-presto-viz.yml` in LMR2:

```yaml
name: Test Presto Visualization

on:
  workflow_dispatch:

jobs:
  test-viz:
    name: Test Visualization
    uses: DaveEdge1/presto-viz/.github/workflows/presto-viz-reusable.yml@main
    with:
      reconstruction_id: test_${{ github.run_number }}
      artifact_name: your-existing-artifact-name
```

## 📊 Step 5: Monitor First Run

1. Go to LMR2 repository → Actions tab
2. Trigger your workflow
3. Watch for the presto-visualization job
4. Check that it:
   - ✅ Clones presto-viz repository
   - ✅ Downloads your NetCDF artifact
   - ✅ Runs three processing scripts
   - ✅ Uploads visualization outputs

## 🎯 Expected Outputs

After successful run, you'll have two artifacts:

1. **presto-viz-logs-{reconstruction_id}**
   - All log files from processing
   - Use for debugging if something fails

2. **presto-viz-output-{reconstruction_id}**
   - Standardized NetCDF file
   - PNG visualizations
   - Interactive HTML file
   - Download and open HTML in browser to view!

## 🐛 Troubleshooting

### Error: "Repository not found"
- **Fix**: Ensure repository is **public**
- **Alternative**: Both repos must be in same GitHub organization

### Error: "Workflow not found"
- **Fix**: Verify workflow file is at `.github/workflows/presto-viz-reusable.yml`
- **Check**: Repository name is correct (DaveEdge1/presto-viz)

### Error: "Artifact not found"
- **Fix**: Ensure artifact name matches exactly between jobs
- **Verify**: Check that cfr-analysis job completed successfully

### Error: "Permission denied"
- **Fix**: Ensure you have push access to GitHub
- **Check**: PAT has correct permissions (repo scope)

## 📝 Important Notes

### Artifact Name Must Match

In your CFR analysis job:
```yaml
- name: Upload outputs
  with:
    name: cfr-netcdf-output  # This name...
```

Must match in visualization job:
```yaml
uses: DaveEdge1/presto-viz/.github/workflows/presto-viz-reusable.yml@main
with:
  artifact_name: cfr-netcdf-output  # ...must match this
```

### NetCDF File Structure

Your NetCDF file should contain:
- Temperature data: `recon_tas_mean`, `recon_tas_ens`
- Global means: `recon_tas_global_mean`
- Coordinates: `lat`, `lon`, `age` or `time`
- Configuration: `configs.yml` in same directory

### Workflow Timeout

Default timeout is 3 hours. For larger datasets:
- Script 1: 15 min (data formatting)
- Script 2: 120 min (maps and time series)
- Script 3: 10 min (HTML generation)

## 🎉 Success Checklist

- [ ] GitHub repository created and public
- [ ] Code pushed to GitHub
- [ ] README displays correctly
- [ ] Workflow file present
- [ ] viz.js excluded
- [ ] LMR2 workflow updated
- [ ] First test run successful
- [ ] Artifacts downloaded
- [ ] HTML visualization viewable

## 🔄 Next Steps After Success

1. **Version Control**: Tag releases for stability
   ```bash
   git tag -a v1.0.0 -m "First stable release"
   git push origin v1.0.0
   ```

2. **Use Specific Version** in LMR2:
   ```yaml
   uses: DaveEdge1/presto-viz/.github/workflows/presto-viz-reusable.yml@v1.0.0
   ```

3. **Zenodo Integration**: Get a DOI for citations
   - Connect repository to Zenodo
   - Create release on GitHub
   - Automatically get DOI

4. **Documentation**: Add to prestoServer README
   ```markdown
   ## Public Components

   The visualization pipeline is available as open source:
   https://github.com/DaveEdge1/presto-viz
   ```

5. **Community**: Enable discussions and issues
   - Settings → Features → Enable Discussions
   - Settings → Features → Enable Issues

## 📚 Reference Documents

Located in prestoServer `.github/workflows/`:
- `NEW-REPO-PLAN.md` - Detailed structure plan
- `SETUP-PUBLIC-REPO.md` - Setup instructions
- `REUSABLE-WORKFLOW-GUIDE.md` - Usage guide

## ❓ Questions?

- **GitHub Issues**: https://github.com/DaveEdge1/presto-viz/issues (after creation)
- **PaleoPresto**: https://paleopresto.com

---

**Ready to push?** Run the commands in Step 2 above!
